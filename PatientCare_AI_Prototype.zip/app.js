/**
 * ==============================================================================
 * PatientCare AI - Frontend Controller (SIH 2026 Problem Statement #47)
 * AI-Assisted Intelligent Patient Case-Taking System
 * ------------------------------------------------------------------------------
 * 11-Step Clinical Pointer Flow with Optional Past Medical History Upload,
 * Multilingual Thank You Screen with 10s Countdown, Audio Voice Narration (TTS/STT),
 * Contradiction Engine, and Doctor Clinical Verification.
 * ==============================================================================
 */

// Application State
let currentRole = "patient";
let currentLanguage = "en";
let isAudioAssistanceOn = true;
let activeCase = null;
let allCases = [];
let recognition = null;
let isRecording = false;
let thankYouCountdownTimer = null;

// Current Registered Patient
let activePatient = {
  name: "Ramesh Verma",
  age: 48,
  gender: "Male",
  phone: "+91 98765 43210",
  language: "hi",
  mode: "assisted"
};

// 11 Comprehensive Clinical Intake Steps
let currentPointerStep = 1;
const TOTAL_POINTER_STEPS = 11;

let intakeAnswers = {
  symptom: "",
  symptom_icon: "",
  triage: "Routine",
  intensity: "",
  character: "",
  duration: "",
  clinical_followup: "",
  clinical_followup_val: null,
  clinical_followup2: "",
  clinical_followup2_val: null,
  is_sugar_patient: null,
  is_bp_patient: null,
  has_documents: false,
  doc_name: "",
  doc_data: "",
  is_daily_meds: null,
  meds_detail: "",
  is_allergic: null,
  allergy_detail: "",
  family_lifestyle: null
};

let detectedContradictions = [];
let patientTranscriptLog = [];

// Multilingual Text & Audio Prompts for Illiterate & Vernacular Patients
const POINTER_PROMPTS = {
  en: {
    regWelcome: "Welcome to PatientCare AI. Please choose your language and register to begin.",
    step1_title: "1. What is your main health trouble today?",
    step1_sub: "Please tap the icon that matches what you feel:",
    step2_title: "2. How severe is the pain and what type of sensation is it?",
    step2_sub: "Select pain intensity and nature:",
    step3_title: "3. How long have you been having this trouble?",
    step3_sub: "Select onset duration:",
    step4_title: "Clinical Follow-up 1: Associated Symptoms & Radiation",
    step4_chest: "Does the chest pain spread to your left arm, shoulder, neck, or jaw? Any cold sweating?",
    step4_stomach: "Does burning or pain spread to your back? Any nausea, acid reflux, or vomiting?",
    step4_fever: "Is fever accompanied by severe shivering chills, phlegm cough, or chest congestion?",
    step4_head: "Is there blurred vision, dizziness, or weakness in your hands or legs?",
    step4_joint: "Is there visible joint swelling, redness, or stiff joints in the morning?",
    step4_other: "Is this symptom causing shortness of breath or dizziness?",
    step5_title: "Clinical Follow-up 2: Triggers, Red Flags & Past Episodes",
    step5_chest: "Does chest heaviness get worse when walking or climbing stairs? Has this happened before?",
    step5_stomach: "Does pain worsen on an empty stomach or after spicy meals? Any dark black stools?",
    step5_fever: "Has high fever lasted continuously for more than 3 days without relief from medicine?",
    step5_head: "Was this a sudden, explosive severe headache with neck stiffness or confusion?",
    step5_joint: "Is it difficult to walk or bear weight on the joints without support?",
    step5_other: "Has this exact problem occurred previously, or required emergency hospital care?",
    step6_title: "6. Past Medical History: Are you a Sugar (Diabetes) patient?",
    step6_sub: "Do you have high blood glucose diagnosed by a doctor?",
    step7_title: "7. Past Medical History: Do you have High Blood Pressure (BP) or Heart trouble?",
    step7_sub: "Have you ever been diagnosed with hypertension or heart disease?",
    step8_title: "8. Past Medical History & Lab Reports: Do you have old reports or doctor prescriptions?",
    step8_sub: "Upload a photo or PDF of your lab report, ECG, or previous prescription (Optional):",
    step9_title: "9. Are you taking regular daily medicines or pain relief pills?",
    step9_sub: "Any daily tablets or painkillers like Ibuprofen, Combiflam, Aspirin?",
    step10_title: "10. Do you have any known allergy to any medicine or injection?",
    step10_sub: "Any skin rash, swelling, or breathing issue from antibiotics or painkillers?",
    step11_title: "11. Any family history of heart disease, or do you consume tobacco?",
    step11_sub: "Lifestyle and family risk assessment:",
    yes_text: "YES",
    no_text: "NO",
    yes_sub: "Yes, I have / Affirmative",
    no_sub: "No, I do not / Negative",
    skip_doc: "⏭️ Skip - I don't have reports right now",
    skip_sub: "Proceed without reports / आगे बढ़ें",
    thank_you_title: "Thank You!",
    thank_you_sub: "Your clinical case intake has been registered successfully.",
    wait_heading: "Please Wait Till Your Call",
    wait_msg: "A doctor will attend to you shortly. You will be called by your token number.",
    next_patient_btn: "➕ Register Next Patient Now",
    redirect_msg: "Returning to New Patient Registration in",
    spoken_thank_you: "Thank you. Your registration is complete. Please wait until your call. A doctor will attend to you shortly."
  },
  hi: {
    regWelcome: "पेशेंटकेयर एआई में आपका स्वागत है। कृपया अपनी भाषा चुनें और पंजीकरण करें।",
    step1_title: "1. आज आपको क्या मुख्य शारीरिक तकलीफ हो रही है?",
    step1_sub: "कृपया नीचे दिए गए चित्र को छूकर चुनें:",
    step2_title: "2. दर्द कितना तेज है और किस तरह का महसूस हो रहा है?",
    step2_sub: "दर्द की तीव्रता और प्रकार चुनें:",
    step3_title: "3. यह तकलीफ आपको कितने समय से हो रही है?",
    step3_sub: "समय अवधि चुनें:",
    step4_title: "क्लिनिकल फॉलो-अप 1: साथ में अन्य लक्षण व फैलाव",
    step4_chest: "क्या सीने का दर्द बाएं हाथ, कंधे, गर्दन या जबड़े में जा रहा है? क्या ठंडा पसीना आ रहा है?",
    step4_stomach: "क्या पेट की जलन या दर्द पीठ की तरफ जाता है? क्या उल्टी, जी मिचलाना या खट्टी डकार है?",
    step4_fever: "क्या तेज कंपकंपी के साथ बुखार, खांसी में बलगम या सांस फूलने की समस्या है?",
    step4_head: "क्या आंखों के सामने धुंधलापन, चक्कर आना या अंगों में कमजोरी महसूस हो रही है?",
    step4_joint: "क्या जोड़ों में सूजन, लालिमा या सुबह उठने पर जोड़ों में तेज जकड़न होती है?",
    step4_other: "क्या इस परेशानी के साथ सांस फूलने या चक्कर आने की समस्या है?",
    step5_title: "क्लिनिकल फॉलो-अप 2: दर्द बढ़ने के कारण व पूर्व इतिहास",
    step5_chest: "क्या चलने या सीढ़ियां चढ़ने पर सीने का भारीपन बढ़ता है? क्या पहले कभी ऐसा हुआ था?",
    step5_stomach: "क्या खाली पेट या तीखा खाने से जलन बढ़ती है? क्या काले रंग का शौच हुआ?",
    step5_fever: "क्या 3 दिन से ज्यादा से लगातार तेज बुखार आ रहा है जो दवा से भी नहीं उतर रहा?",
    step5_head: "क्या अचानक असहनीय तेज सिरदर्द हुआ है साथ में गर्दन में अकड़न है?",
    step5_joint: "क्या बिना सहारे के चलना या जोड़ों पर वजन डालना बहुत मुश्किल हो गया है?",
    step5_other: "क्या यह तकलीफ पहले भी कभी हुई थी या अस्पताल में भर्ती होना पड़ा था?",
    step6_title: "6. पुराना इतिहास: क्या आपको शुगर (डायबिटीज) की बीमारी है?",
    step6_sub: "क्या डॉक्टर ने खून में शुगर की बीमारी बताई है?",
    step7_title: "7. पुराना इतिहास: क्या आपको ब्लड प्रेशर (बीपी) या दिल की बीमारी है?",
    step7_sub: "क्या पहले कभी बीपी की जांच में अधिक रक्तचाप या दिल का रोग आया है?",
    step8_title: "8. पुरानी मेडिकल रिपोर्ट व पर्चे: क्या आपके पास कोई पुरानी जांच रिपोर्ट या पर्चा है?",
    step8_sub: "पुरानी रिपोर्ट, ईसीजी या डॉक्टर के पर्चे की फोटो अपलोड करें (वैकल्पिक):",
    step9_title: "9. क्या आप कोई रोज की दवा या दर्द निवारक गोली ले रहे हैं?",
    step9_sub: "जैसे इबुप्रोफेन, कॉम्बीफ्लेम, एस्पिरिन या बीपी/शुगर की गोली:",
    step10_title: "10. क्या आपको किसी दवा या सुई से कोई एलर्जी है?",
    step10_sub: "दवा खाने से शरीर पर लाल चकत्ते, खुजली या सांस की दिक्कत हुई हो?",
    step11_title: "11. क्या परिवार में किसी को दिल का दौरा पड़ा है, या आप बीड़ी/तंबाकू लेते हैं?",
    step11_sub: "पारिवारिक इतिहास और जीवनशैली की जांच:",
    yes_text: "हाँ (YES)",
    no_text: "नहीं (NO)",
    yes_sub: "हाँ, मुझे है",
    no_sub: "नहीं, मुझे नहीं है",
    skip_doc: "⏭️ मेरे पास अभी रिपोर्ट नहीं है (आगे बढ़ें)",
    skip_sub: "Skip (I don't have reports right now)",
    thank_you_title: "धन्यवाद!",
    thank_you_sub: "आपकी स्वास्थ्य जानकारी सफलतापूर्वक दर्ज हो गई है।",
    wait_heading: "कृपया अपनी बारी की प्रतीक्षा करें",
    wait_msg: "डॉक्टर जल्द ही आपको बुलाएंगे। आपको टोकन नंबर से बुलाया जाएगा।",
    next_patient_btn: "➕ तुरंत अगला मरीज दर्ज करें",
    redirect_msg: "नए मरीज के पंजीकरण फॉर्म पर लौटने में शेष समय",
    spoken_thank_you: "धन्यवाद। आपका पंजीकरण पूरा हो गया है। कृपया प्रतीक्षा करें, डॉक्टर जल्द ही आपको बुलाएंगे।"
  },
  ta: {
    regWelcome: "PatientCare AI-க்கு வரவேற்கிறோம். தயவுசெய்து பதிவு செய்யவும்.",
    step1_title: "1. இன்று உங்களுக்கு என்ன உடல்நல பிரச்சனை?",
    step1_sub: "பொருத்தமான குறியீட்டைத் தேர்ந்தெடுக்கவும்:",
    step2_title: "2. வலியின் தீவிரம் எப்படி உள்ளது?",
    step2_sub: "தீவிரத்தைத் தேர்ந்தெடுக்கவும்:",
    step3_title: "3. இந்த பிரச்சனை எத்தனை நாட்களாக உள்ளது?",
    step3_sub: "கால அளவைத் தேர்ந்தெடுக்கவும்:",
    step4_title: "மருத்துவ பரிசோதனை 1: தொடர்புடைய அறிகுறிகள்",
    step4_chest: "நெஞ்சு வலி இடது கை அல்லது தாடைக்கு பரவுகிறதா? வியர்க்கிறதா?",
    step4_stomach: "எரியும் வலி முதுகுக்கு பரவுகிறதா? வாந்தி உள்ளதா?",
    step4_fever: "குளிர்க்காய்ச்சல் அல்லது மூச்சுத்திணறல் உள்ளதா?",
    step4_head: "பார்வை மங்கலாக உள்ளதா அல்லது மயக்கம் வருகிறதா?",
    step4_joint: "மூட்டுகளில் வீக்கம் அல்லது காலையில் இறுக்கம் உள்ளதா?",
    step4_other: "மூச்சுத்திணறல் அல்லது மயக்கம் உள்ளதா?",
    step5_title: "மருத்துவ பரிசோதனை 2: தீவிர எச்சரிக்கை",
    step5_chest: "நடக்கும் போது அல்லது படிக்கட்டுகளில் ஏறும் போது நெஞ்சு வலி அதிகரிக்கிறதா?",
    step5_stomach: "வெறும் வயிற்றில் வலி அதிகரிக்கிறதா? கருப்பு மலம் வெளியேறியதா?",
    step5_fever: "3 நாட்களுக்கு மேலாக தொடர்ந்து காய்ச்சல் உள்ளதா?",
    step5_head: "திடீரென மிகக் கடுமையான தலைவலி ஏற்பட்டதா?",
    step5_joint: "நடக்க முடியாத அளவுக்கு வலி உள்ளதா?",
    step5_other: "முன்பு எப்போதாவது அவசர சிகிச்சை தேவைப்பட்டதா?",
    step6_title: "6. முந்தைய வரலாறு: உங்களுக்கு சர்க்கரை நோய் உள்ளதா?",
    step6_sub: "நீரிழிவு நோய் உள்ளதா?",
    step7_title: "7. முந்தைய வரலாறு: உங்களுக்கு ரத்த அழுத்தம் (BP) உள்ளதா?",
    step7_sub: "இதய நோய் உள்ளதா?",
    step8_title: "8. பழைய மருத்துவ பரிசோதனை அறிக்கைகள் உள்ளதா?",
    step8_sub: "அறிக்கையை பதிவேற்றவும் (விருப்பத்தேர்வு):",
    step9_title: "9. தினமும் ஏதேனும் வலி மாத்திரைகள் எடுக்கிறீர்களா?",
    step9_sub: "தினசரி மருந்துகள்:",
    step10_title: "10. ஏதேனும் மருந்து ஒவ்வாமை (Allergy) உள்ளதா?",
    step10_sub: "மருந்து ஒவ்வாமை:",
    step11_title: "11. குடும்பத்தில் யாருக்கேனும் இதய நோய் உள்ளதா?",
    step11_sub: "வாழ்க்கை முறை:",
    yes_text: "ஆம் (YES)",
    no_text: "இல்லை (NO)",
    yes_sub: "ஆம், உள்ளது",
    no_sub: "இல்லை",
    skip_doc: "⏭️ அறிக்கைகள் இல்லை (தவிர்க்கவும்)",
    skip_sub: "Skip Document Upload",
    thank_you_title: "நன்றி!",
    thank_you_sub: "உங்கள் மருத்துவ விவரங்கள் வெற்றிகரமாக பதிவு செய்யப்பட்டன.",
    wait_heading: "தயவுசெய்து உங்கள் முறை வரும் வரை காத்திருக்கவும்",
    wait_msg: "மருத்துவர் விரைவில் உங்களை அழைப்பார். டோக்கன் எண் மூலம் அழைக்கப்படுவீர்கள்.",
    next_patient_btn: "➕ அடுத்த நோயாளியைப் பதிவு செய்யவும்",
    redirect_msg: "புதிய நோயாளி பதிவுக்குத் திரும்பும் நேரம்",
    spoken_thank_you: "நன்றி. உங்கள் பதிவு முடிந்தது. உங்கள் முறை வரும் வரை காத்திருக்கவும். மருத்துவர் விரைவில் உங்களை அழைப்பார்."
  },
  te: {
    regWelcome: "PatientCare AI కి స్వాగతం. దయచేసి వివరాలు నమోదు చేయండి.",
    step1_title: "1. ఈ రోజు మీకు ప్రధాన సమస్య ఏమిటి?",
    step1_sub: "సరిపోయే చిత్రాన్ని తాకండి:",
    step2_title: "2. నొప్పి తీవ్రత ఎలా ఉంది?",
    step2_sub: "తీవ్రతను ఎంచుకోండి:",
    step3_title: "3. ఈ సమస్య ఎన్ని రోజుల నుంచి ఉంది?",
    step3_sub: "సమయాన్ని ఎంచుకోండి:",
    step4_title: "క్లినికల్ ఫాలో-అప్ 1: సంబంధిత లక్షణాలు",
    step4_chest: "ఛాతీ నొప్పి ఎడమ చేతికి లేదా దవడకు వ్యాపిస్తుందా? చెమటలు పడుతున్నాయా?",
    step4_stomach: "కడుపు మంట లేదా నొప్పి వెనుకకు వ్యాపిస్తుందా? వాంతులు ఉన్నాయా?",
    step4_fever: "వణుకుతో కూడిన జ్వరం లేదా శ్వాస ఆడకపోవటం ఉందా?",
    step4_head: "కళ్ళు తిరగడం లేదా చూపు మసకబారడం ఉందా?",
    step4_joint: "కీళ్ల వాపు లేదా ఉదయం పూట బిగుతుగా ఉండటం ఉందా?",
    step4_other: "శ్వాస ఆడకపోవటం లేదా మైకం ఉందా?",
    step5_title: "క్లినికల్ ఫాలో-అప్ 2: తీవ్రత మరియు గత చరిత్ర",
    step5_chest: "నడిచేటప్పుడు లేదా మెట్లు ఎక్కేటప్పుడు ఛాతీ నొప్పి పెరుగుతుందా?",
    step5_stomach: "ఖాళీ కడుపుతో ఉన్నప్పుడు మంట పెరుగుతుందా? నల్లటి విరేచనాలు అయ్యాయా?",
    step5_fever: "3 రోజులకు పైగా నిరంతరం జ్వరం తగ్గకుండా ఉందా?",
    step5_head: "హఠాత్తుగా తీవ్రమైన తలనొప్పి మరియు మెడ పట్టేయడం జరిగిందా?",
    step5_joint: "ఆధారం లేకుండా నడవడం చాలా కష్టంగా ఉందా?",
    step5_other: "గతంలో ఎప్పుడైనా ఆసుపత్రిలో చేరాల్సి వచ్చిందా?",
    step6_title: "6. గత చరిత్ర: మీకు షుగర్ (డయాబెటిస్) వ్యాధి ఉందా?",
    step6_sub: "షుగర్ లెవల్స్ ఎక్కువా?",
    step7_title: "7. గత చరిత్ర: మీకు రక్తపోటు (BP) లేదా గుండె సమస్య ఉందా?",
    step7_sub: "బీపీ ఉందా?",
    step8_title: "8. పాత ల్యాబ్ రిపోర్టులు లేదా మందుల చీటీలు ఉన్నాయా?",
    step8_sub: "రిపోర్టును అప్‌లోడ్ చేయండి (ఐచ్ఛికం):",
    step9_title: "9. మీరు రోజూ ఏవైనా మందులు లేదా పెయిన్ కిల్లర్స్ వాడుతున్నారా?",
    step9_sub: "రోజువారీ మందులు:",
    step10_title: "10. ఏదైనా మందుతో మీకు అలెర్జీ ఉందా?",
    step10_sub: "మందుల అలెర్జీ:",
    step11_title: "11. కుటుంబంలో ఎవరికైనా గుండెజబ్బు ఉందా?",
    step11_sub: "కుటుంబ చరిత్ర:",
    yes_text: "అవును (YES)",
    no_text: "కాదు (NO)",
    yes_sub: "అవును, ఉంది",
    no_sub: "లేదు",
    skip_doc: "⏭️ రిపోర్టులు లేవు (దాటవేయండి)",
    skip_sub: "Skip Document Upload",
    thank_you_title: "ధన్యవాదాలు!",
    thank_you_sub: "మీ ఆరోగ్య వివరాలు విజయవంతంగా నమోదు చేయబడ్డాయి.",
    wait_heading: "దయచేసి మీ పిలుపు వచ్చేవరకు వేచి ఉండండి",
    wait_msg: "వైద్యులు త్వరలో మిమ్మల్ని పిలుస్తారు. మీ టోకెన్ నంబర్ ప్రకారం పిలుస్తారు.",
    next_patient_btn: "➕ తదుపరి రోగిని నమోదు చేయండి",
    redirect_msg: "కొత్త రోగి నమోదుకు తిరిగి వెళ్ళడానికి సమయం",
    spoken_thank_you: "ధన్యవాదాలు. మీ నమోదు పూర్తయింది. దయచేసి వేచి ఉండండి, వైద్యులు త్వరలో మిమ్మల్ని పిలుస్తారు."
  },
  bn: {
    regWelcome: "PatientCare AI-তে স্বাগতম। দয়া করে তথ্য দিয়ে শুরু করুন।",
    step1_title: "1. আজ আপনার কী শারীরিক সমস্যা হচ্ছে?",
    step1_sub: "নিচের ছবিতে স্পর্শ করে বেছে নিন:",
    step2_title: "2. ব্যথার তীব্রতা কেমন?",
    step2_sub: "তীব্রতা বেছে নিন:",
    step3_title: "3. কত দিন ধরে এই সমস্যা হচ্ছে?",
    step3_sub: "সময়কাল বেছে নিন:",
    step4_title: "ক্লিনিক্যাল ফলো-আপ ১: আনুষঙ্গিক লক্ষণ",
    step4_chest: "বুকে ব্যথা কি বাঁ হাত, কাঁধ বা চোয়ালে ছড়াচ্ছে? ঘাম হচ্ছে কি?",
    step4_stomach: "পেটে জ্বালা বা ব্যথা কি পিঠের দিকে ছড়াচ্ছে? বমি হচ্ছে কি?",
    step4_fever: "কাঁপুনি দিয়ে জ্বর বা বুকে কফ ও শ্বাসকষ্ট আছে কি?",
    step4_head: "চোখে ঝাপসা দেখা বা মাথা ঘোরার সমস্যা আছে?",
    step4_joint: "জয়েন্টে ফোলাভাব বা সকালে অসাড়তা আছে কি?",
    step4_other: "শ্বাসকষ্ট বা মাথা ঘোরার সমস্যা হচ্ছে কি?",
    step5_title: "ক্লিনিক্যাল ফলো-আপ ২: তীব্রতা ও পূর্ব ইতিহাস",
    step5_chest: "হাঁটার সময় কি বুকের চাপ বা ব্যথা বেড়ে যায়? আগে কি এমন হয়েছিল?",
    step5_stomach: "খালি পেটে বা ঝাল খেলে কি জ্বালা বাড়ে? কালো পায়খানা হয়েছে?",
    step5_fever: "৩ দিনের বেশি সময় ধরে কি ওষুধেও জ্বর কমছে না?",
    step5_head: "হঠাৎ প্রচণ্ড তীব্র মাথাব্যথা এবং ঘাড়ে শক্ত ভাব হয়েছে কি?",
    step5_joint: "ভর দিয়ে হাঁটা কি সম্পূর্ণ অসম্ভব হয়ে গেছে?",
    step5_other: "আগে কি কখনো এই সমস্যার জন্য হাসপাতালে ভর্তি হতে হয়েছিল?",
    step6_title: "6. পূর্বের ইতিহাস: আপনার কি সুগার (ডায়াবেটিস) আছে?",
    step6_sub: "রক্তে শর্করার মাত্রা বেশি?",
    step7_title: "7. পূর্বের ইতিহাস: আপনার কি ব্লাড প্রেসার (BP) বা হার্টের সমস্যা আছে?",
    step7_sub: "প্রেসার আছে কি?",
    step8_title: "8. আপনার কি কোনো পূর্বের মেডিকেল রিপোর্ট বা প্রেসক্রিপশন আছে?",
    step8_sub: "রিপোর্ট আপলোড করুন (ঐচ্ছিক):",
    step9_title: "9. আপনি কি প্রতিদিন কোনো ব্যথানাশক বা অন্যান্য ওষুধ খান?",
    step9_sub: "নিয়মিত ওষুধ:",
    step10_title: "10. কোনো ওষুধে আপনার অ্যালার্জি আছে কি?",
    step10_sub: "ওষুধের অ্যালার্জি:",
    step11_title: "11. পরিবারে কারো হৃদরোগের ইতিহাস আছে কি?",
    step11_sub: "পারিবারিক ইতিহাস:",
    yes_text: "হ্যাঁ (YES)",
    no_text: "না (NO)",
    yes_sub: "হ্যাঁ, আছে",
    no_sub: "না, নেই",
    skip_doc: "⏭️ রিপোর্ট নেই (পরবর্তী পদক্ষেপে যান)",
    skip_sub: "Skip Document Upload",
    thank_you_title: "ধন্যবাদ!",
    thank_you_sub: "আপনার স্বাস্থ্য সম্পর্কিত তথ্য সফলভাবে নথিভুক্ত হয়েছে।",
    wait_heading: "দয়া করে আপনার ডাক আসা পর্যন্ত অপেক্ষা করুন",
    wait_msg: "ডাক্তারবাবু শীঘ্রই আপনাকে ডাকবেন। আপনার টোকেন নম্বর ধরে ডাকা হবে।",
    next_patient_btn: "➕ পরবর্তী রোগী নথিভুক্ত করুন",
    redirect_msg: "নতুন রোগী রেজিস্ট্রেশনে ফেরার সময় বাকি",
    spoken_thank_you: "ধন্যবাদ। আপনার রেজিস্ট্রেশন সম্পন্ন হয়েছে। দয়া করে অপেক্ষা করুন, ডাক্তারবাবু শীঘ্রই আপনাকে ডাকবেন।"
  },
  mr: {
    regWelcome: "PatientCare AI मध्ये आपले स्वागत आहे. कृपया नोंदणी करा.",
    step1_title: "1. आज तुम्हाला नेमका काय त्रास होत आहे?",
    step1_sub: "खालील चिन्हावर क्लिक करा:",
    step2_title: "2. वेदना किती तीव्र आहे आणि कशी जाणवते?",
    step2_sub: "तीव्रता व प्रकार निवडा:",
    step3_title: "3. हा त्रास किती दिवसांपासून होत आहे?",
    step3_sub: "कालावधी निवडा:",
    step4_title: "क्लिनिकल फॉलो-अप १: सोबत इतर लक्षणे",
    step4_chest: "छातीत दुखणे डाव्या हाताकडे, खांद्याकडे किंवा जबड्याकडे जाते का? घाम येतोय का?",
    step4_stomach: "पोटात जळजळ किंवा वेदना पाठीकडे जाते का? उलटी किंवा मळमळ होते का?",
    step4_fever: "थंडी वाजून ताप येतो का किंवा खोकल्यात कफ व धाप लागते का?",
    step4_head: "डोळ्यांसमोर अंधारी येणे किंवा चक्कर येते का?",
    step4_joint: "सांध्यांना सूज आली आहे का किंवा सकाळी सांधे आखडतात का?",
    step4_other: "धाप लागणे किंवा चक्कर येण्याचा त्रास होतोय का?",
    step5_title: "क्लिनिकल फॉलो-अप २: वेदना वाढण्याची कारणे",
    step5_chest: "चालताना किंवा जिना चढताना छातीवरील दाब वाढतो का? आधी असा त्रास झाला होता का?",
    step5_stomach: "उपाशीपोटी जळजळ वाढते का? काळ्या रंगाचे शौचास झाले आहे का?",
    step5_fever: "औषध घेऊनही ३ दिवसांपेक्षा जास्त काळ सतत ताप भरतोय का?",
    step5_head: "अचानक अतिशय तीव्र डोकेदुखी व मानेमध्ये ताठरता आली आहे का?",
    step5_joint: "आधाराशिवाय चालणे किंवा सांध्यावर वजन देणे कठीण झाले आहे का?",
    step5_other: "आधी कधी या त्रासासाठी रुग्णालयात दाखल व्हावे लागले होते का?",
    step6_title: "6. जुना आजार: तुम्हाला मधुमेहाचा (शुगरचा) आजार आहे का?",
    step6_sub: "शुगर जास्त आहे का?",
    step7_title: "7. जुना आजार: तुम्हाला ब्लड प्रेशर (BP) किंवा हृदयाचा त्रास आहे का?",
    step7_sub: "बीपीचा त्रास आहे का?",
    step8_title: "8. जुनी तपासणी रिपोर्ट किंवा औषधांची चिठ्ठी आहे का?",
    step8_sub: "रिपोर्ट अपलोड करा (ऐच्छिक असल्यास):",
    step9_title: "9. तुम्ही रोजची काही औषधे किंवा पेनकिलर गोळ्या घेता का?",
    step9_sub: "दररोजची औषधे:",
    step10_title: "10. कोणत्याही औषधाची तुम्हाला ॲलर्जी आहे का?",
    step10_sub: "गोळ्यांची ॲलर्जी:",
    step11_title: "11. कुटुंबात कुणाला हृदयविकाराचा इतिहास आहे का?",
    step11_sub: "कौटुंबिक माहिती:",
    yes_text: "होय (YES)",
    no_text: "नाही (NO)",
    yes_sub: "होय, आहे",
    no_sub: "नाही, नाहीये",
    skip_doc: "⏭️ रिपोर्ट उपलब्ध नाही (पुढे जा)",
    skip_sub: "Skip Document Upload",
    thank_you_title: "धन्यवाद!",
    thank_you_sub: "तुमची आरोग्य माहिती यशस्वीरित्या नोंदवली गेली आहे.",
    wait_heading: "कृपया आपली पाळी येईपर्यंत प्रतीक्षा करा",
    wait_msg: "डॉक्टर लवकरच आपल्याला तपासतील. आपल्या टोकन नंबरने हाक मारली जाईल.",
    next_patient_btn: "➕ पुढील रुग्णाची नोंदणी करा",
    redirect_msg: "नवीन रुग्णाच्या नोंदणीकडे परत जाण्याची वेळ",
    spoken_thank_you: "धन्यवाद. आपली नोंदणी पूर्ण झाली आहे. कृपया प्रतीक्षा करा, डॉक्टर लवकरच आपल्याला बोलवतील."
  },
  gu: {
    regWelcome: "PatientCare AI માં આપનું સ્વાગત છે. કૃપા કરીને નોંધણી કરો.",
    step1_title: "1. આજે તમને શું મુખ્ય તકલીફ છે?",
    step1_sub: "યોગ્ય નિશાની પર ક્લિક કરો:",
    step2_title: "2. દુખાવો કેટલો તીવ્ર છે?",
    step2_sub: "તીવ્રતા પસંદ કરો:",
    step3_title: "3. આ તકલીફ કેટલા સમયથી છે?",
    step3_sub: "સમય પસંદ કરો:",
    step4_title: "ક્લિનિકલ ફોલો-અપ 1: સાથે અન્ય લક્ષણો",
    step4_chest: "છાતીનો દુખાવો ડાબા હાથ, ખભા કે જડબામાં જાય છે? પરસેવો વળે છે?",
    step4_stomach: "પેટની બળતરા કે દુખાવો પીઠ તરફ જાય છે? ઉલટી જેવું થાય છે?",
    step4_fever: "ધ્રૂજારી સાથે તાવ કે શ્વાસ લેવામાં તકલીફ છે?",
    step4_head: "ચક્કર આવે છે કે આંખે અંધારા આવે છે?",
    step4_joint: "સાંધામાં સોજો છે કે સવારે અકડાઈ જાય છે?",
    step4_other: "શ્વાસ ચડવો કે ચક્કર આવવાની તકલીફ છે?",
    step5_title: "ક્લિનિકલ ફોલો-અપ 2: દુખાવો વધવાનાં કારણો",
    step5_chest: "ચાલતી વખતે છાતીમાં દબાણ વધે છે? પહેલાં ક્યારેય આવું થયું છે?",
    step5_stomach: "ખાલી પેટે બળતરા વધે છે? કાળા રંગનો ઝાડો થયો છે?",
    step5_fever: "દવા લેવા છતાં 3 દિવસથી વધુ સમયથી સતત તાવ રહે છે?",
    step5_head: "અચાનક અત્યંત તીવ્ર માથાનો દુખાવો અને ગરદનમાં અકડાઈ આવી છે?",
    step5_joint: "ટેકા વિના ચાલવું કે વજન આપવું મુશ્કેલ છે?",
    step5_other: "પહેલાં ક્યારેય આ તકલીફ માટે હોસ્પિટલમાં દાખલ થવું પડ્યું હતું?",
    step6_title: "6. જૂનો ઇતિહાસ: શું તમને સુગર (ડાયાબિટીસ) ની બીમારી છે?",
    step6_sub: "સુગર વધારે રહે છે?",
    step7_title: "7. જૂનો ઇતિહાસ: શું તમને બ્લડ પ્રેશર (BP) કે હૃદયની તકલીફ છે?",
    step7_sub: "બીપી છે?",
    step8_title: "8. જૂના લેબ રિપોર્ટ કે દવાઓની ચિઠ્ઠી છે?",
    step8_sub: "રિપોર્ટ અપલોડ કરો (મરજિયાત):",
    step9_title: "9. શું તમે રોજ કોઈ દવા કે પેઇન કિલર ગોળી લો છો?",
    step9_sub: "રોજની દવાઓ:",
    step10_title: "10. શું તમને કોઈ દવા અથવા ઇન્જેક્શનથી એલર્જી છે?",
    step10_sub: "દવાની એલર્જી:",
    step11_title: "11. પરિવારમાં કોઈને હૃદયરોગનો ઇતિહાસ છે?",
    step11_sub: "જીવનશૈલી:",
    yes_text: "હા (YES)",
    no_text: "ના (NO)",
    yes_sub: "હા, છે",
    no_sub: "ના, નથી",
    skip_doc: "⏭️ રિપોર્ટ નથી (આગળ વધો)",
    skip_sub: "Skip Document Upload",
    thank_you_title: "આભાર!",
    thank_you_sub: "તમારી આરોગ્ય વિગતો સફળતાપૂર્વક નોંધાઈ ગઈ છે.",
    wait_heading: "કૃપા કરીને તમારો વારો આવે ત્યાં સુધી રાહ જુઓ",
    wait_msg: "ડૉક્ટર ટૂંક સમયમાં તમને બોલાવશે. તમને ટોકન નંબર દ્વારા બોલાવવામાં આવશે.",
    next_patient_btn: "➕ પછીના દર્દીની નોંધણી કરો",
    redirect_msg: "નવા દર્દીની નોંધણી પર પાછા જવાનો સમય",
    spoken_thank_you: "આભાર. તમારી નોંધણી પૂર્ણ થઈ ગઈ છે. કૃપા કરીને રાહ જુઓ, ડૉક્ટર ટૂંક સમયમાં તમને બોલાવશે."
  }
};

// ==============================================================================
// INITIALIZATION
// ==============================================================================
window.addEventListener("DOMContentLoaded", () => {
  loadStoredCases();
  initVoiceRecognition();
  updateDoctorStats();
});

async function loadStoredCases() {
  try {
    const res = await fetch("/api/cases");
    if (res.ok) {
      const data = await res.json();
      allCases = data.cases || [];
    } else {
      throw new Error("API not reachable");
    }
  } catch (err) {
    const local = localStorage.getItem("patientcare_cases");
    if (local) {
      allCases = JSON.parse(local);
    }
  }
  updateDoctorStats();
  renderCasesTable(allCases);
}

// ==============================================================================
// REGISTRATION & LANGUAGE
// ==============================================================================
function selectLanguage(langCode, btnElement) {
  currentLanguage = langCode;
  document.querySelectorAll(".lang-chip").forEach(c => c.classList.remove("active"));
  btnElement.classList.add("active");

  const p = POINTER_PROMPTS[langCode] || POINTER_PROMPTS.en;
  speakCurrentText(p.regWelcome);
}

function fillQuickProfile(type) {
  if (type === "cardiac") {
    document.getElementById("regName").value = "Rajesh Kumar";
    document.getElementById("regAge").value = "52";
    document.getElementById("regGender").value = "Male";
    document.getElementById("regPhone").value = "+91 98765 43210";
    selectLanguage('hi', document.querySelector('[data-lang="hi"]'));
  } else if (type === "gastric") {
    document.getElementById("regName").value = "Sunita Devi";
    document.getElementById("regAge").value = "38";
    document.getElementById("regGender").value = "Female";
    document.getElementById("regPhone").value = "+91 94123 78901";
    selectLanguage('hi', document.querySelector('[data-lang="hi"]'));
  } else if (type === "pediatric") {
    document.getElementById("regName").value = "Aarav Patel";
    document.getElementById("regAge").value = "8";
    document.getElementById("regGender").value = "Male";
    document.getElementById("regPhone").value = "+91 97234 11223";
    selectLanguage('gu', document.querySelector('[data-lang="gu"]'));
  }
}

function handleRegistrationSubmit(e) {
  e.preventDefault();
  activePatient.name = document.getElementById("regName").value.trim() || "Anonymous Patient";
  activePatient.age = parseInt(document.getElementById("regAge").value) || 30;
  activePatient.gender = document.getElementById("regGender").value;
  activePatient.phone = document.getElementById("regPhone").value.trim();
  activePatient.mode = document.getElementById("regPatientType").value;
  activePatient.language = currentLanguage;

  document.getElementById("activePatientName").textContent = activePatient.name;
  document.getElementById("activePatientMeta").textContent = `${activePatient.age} Yrs • ${activePatient.gender} • Lang: ${currentLanguage.toUpperCase()}`;

  // Reset transcript and answers for this fresh intake
  patientTranscriptLog = [];
  detectedContradictions = [];
  intakeAnswers = {
    symptom: "",
    symptom_icon: "",
    triage: "Routine",
    intensity: "",
    character: "",
    duration: "",
    clinical_followup: "",
    clinical_followup_val: null,
    clinical_followup2: "",
    clinical_followup2_val: null,
    is_sugar_patient: null,
    is_bp_patient: null,
    has_documents: false,
    doc_name: "",
    doc_data: "",
    is_daily_meds: null,
    meds_detail: "",
    is_allergic: null,
    allergy_detail: "",
    family_lifestyle: null
  };

  document.getElementById("registrationView").classList.remove("active");
  document.getElementById("pointerIntakeView").classList.add("active");
  document.getElementById("doctorView").classList.remove("active");

  const voiceBar = document.querySelector(".voice-illiterate-bar");
  if (voiceBar) voiceBar.style.display = "flex";

  currentPointerStep = 1;
  renderPointerQuestion(1);
}

function returnToRegistration() {
  document.getElementById("pointerIntakeView").classList.remove("active");
  document.getElementById("registrationView").classList.add("active");
}

// ==============================================================================
// 11-STEP COMPREHENSIVE CLINICAL POINTER QUESTIONS
// ==============================================================================
function renderPointerQuestion(step) {
  currentPointerStep = step;
  updateStepperIndicator(step);

  const container = document.getElementById("pointerQuestionBox");
  const p = POINTER_PROMPTS[currentLanguage] || POINTER_PROMPTS.en;
  const header = document.getElementById("pointerStepHeader");

  // STEP 1: Primary Symptom
  if (step === 1) {
    header.textContent = `Question 1: ${p.step1_title}`;
    container.innerHTML = `
      <div class="pointer-question-prompt">
        <div class="pointer-title-main">${p.step1_title}</div>
        <div class="pointer-title-sub">${p.step1_sub}</div>
      </div>

      <div class="symptom-cards-grid">
        <button type="button" class="symptom-tile" onclick="selectSymptom('Chest Pain / Pressure (सीने में दर्द या भारीपन)', '🫀', 'Emergency')">
          <div class="symptom-icon">🫀</div>
          <div>
            <div class="symptom-name">Chest Pain / Heaviness</div>
            <div class="symptom-desc">सीने में दर्द, भारीपन या दबाव</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectSymptom('Stomach Burning / Pain (पेट में तेज जलन या दर्द)', '🤰', 'Priority')">
          <div class="symptom-icon">🤰</div>
          <div>
            <div class="symptom-name">Stomach Burning / Acid</div>
            <div class="symptom-desc">पेट में जलन, गैस, उलटी या दर्द</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectSymptom('High Fever & Cough (तेज बुखार और खांसी)', '🌡️', 'Routine')">
          <div class="symptom-icon">🌡️</div>
          <div>
            <div class="symptom-name">Fever & Cough</div>
            <div class="symptom-desc">तेज बुखार, खांसी या जुकाम</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectSymptom('Severe Headache & Vertigo (तेज सिरदर्द व चक्कर)', '🤕', 'Priority')">
          <div class="symptom-icon">🤕</div>
          <div>
            <div class="symptom-name">Headache / Dizziness</div>
            <div class="symptom-desc">तेज सिरदर्द, माइग्रेन या चक्कर</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectSymptom('Joint / Bone Pain (जोड़ों और बदन में दर्द)', '🦵', 'Routine')">
          <div class="symptom-icon">🦵</div>
          <div>
            <div class="symptom-name">Joint & Body Ache</div>
            <div class="symptom-desc">घुटनों, जोड़ों या कमर का दर्द</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectSymptom('General Illness / Other (सामान्य कमजोरी / अन्य)', '➕', 'Routine')">
          <div class="symptom-icon">➕</div>
          <div>
            <div class="symptom-name">Other Symptoms</div>
            <div class="symptom-desc">अन्य शारीरिक परेशानी</div>
          </div>
        </button>
      </div>
    `;
    speakCurrentText(p.step1_title);

  // STEP 2: Intensity & Nature of Pain
  } else if (step === 2) {
    header.textContent = `Question 2: ${p.step2_title}`;
    container.innerHTML = `
      <div class="pointer-question-prompt">
        <div class="pointer-title-main">${p.step2_title}</div>
        <div class="pointer-title-sub">${p.step2_sub}</div>
      </div>

      <div style="margin-bottom:1rem;">
        <label style="font-size:0.85rem; font-weight:700; color:var(--primary); margin-bottom:0.4rem; display:block;">
          Pain / Distress Level (दर्द का स्तर):
        </label>
        <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:0.75rem;">
          <button type="button" class="btn-pointer-choice" style="background:#f0fdf4; border:2px solid #86efac; padding:1rem;" onclick="selectIntensity('Mild (हल्का - 1 to 3)')">
            <span style="font-size:1.8rem;">🙂</span>
            <span style="font-weight:700; color:#15803d;">Mild (हल्का)</span>
          </button>
          <button type="button" class="btn-pointer-choice" style="background:#fffbeb; border:2px solid #fde68a; padding:1rem;" onclick="selectIntensity('Moderate (मध्यम - 4 to 6)')">
            <span style="font-size:1.8rem;">😐</span>
            <span style="font-weight:700; color:#b45309;">Moderate (मध्यम)</span>
          </button>
          <button type="button" class="btn-pointer-choice" style="background:#fef2f2; border:2px solid #fca5a5; padding:1rem;" onclick="selectIntensity('Severe (असहनीय - 7 to 10)')">
            <span style="font-size:1.8rem;">😫</span>
            <span style="font-weight:700; color:#b91c1c;">Severe (असहनीय)</span>
          </button>
        </div>
      </div>

      <label style="font-size:0.85rem; font-weight:700; color:var(--primary); margin-bottom:0.4rem; display:block;">
        Feeling Type / दर्द का अहसास:
      </label>
      <div class="symptom-cards-grid">
        <button type="button" class="symptom-tile" onclick="selectCharacter('Crushing / Heavy (भारी दबाव जैसा)')">
          <div class="symptom-icon">🏋️</div>
          <div>
            <div class="symptom-name">Heavy / Crushing</div>
            <div class="symptom-desc">भारी दबाव जैसा अहसास</div>
          </div>
        </button>
        <button type="button" class="symptom-tile" onclick="selectCharacter('Burning / Acidic (तेज जलन जैसा)')">
          <div class="symptom-icon">🔥</div>
          <div>
            <div class="symptom-name">Burning / Acidic</div>
            <div class="symptom-desc">आग या एसिड जैसी जलन</div>
          </div>
        </button>
        <button type="button" class="symptom-tile" onclick="selectCharacter('Sharp / Stabbing (चुभने वाला दर्द)')">
          <div class="symptom-icon">⚡</div>
          <div>
            <div class="symptom-name">Sharp / Stabbing</div>
            <div class="symptom-desc">तीखा सुई जैसा चुभन</div>
          </div>
        </button>
        <button type="button" class="symptom-tile" onclick="selectCharacter('Dull Continuous Ache (मीठा लगातार दर्द)')">
          <div class="symptom-icon">🩹</div>
          <div>
            <div class="symptom-name">Dull Continuous Ache</div>
            <div class="symptom-desc">लगातार मीठा दर्द</div>
          </div>
        </button>
      </div>
    `;
    speakCurrentText(p.step2_title);

  // STEP 3: Duration & Onset
  } else if (step === 3) {
    header.textContent = `Question 3: ${p.step3_title}`;
    container.innerHTML = `
      <div class="pointer-question-prompt">
        <div class="pointer-title-main">${p.step3_title}</div>
        <div class="pointer-title-sub">${p.step3_sub}</div>
      </div>

      <div class="symptom-cards-grid">
        <button type="button" class="symptom-tile" onclick="selectDuration('Just Today (< 24 Hours / आज ही शुरू हुआ)')">
          <div class="symptom-icon">⏱️</div>
          <div>
            <div class="symptom-name">Just Today (&lt; 24 Hours)</div>
            <div class="symptom-desc">आज ही या कुछ घंटों से</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectDuration('2 to 4 Days (2 से 4 दिनों से)')">
          <div class="symptom-icon">📅</div>
          <div>
            <div class="symptom-name">2 to 4 Days</div>
            <div class="symptom-desc">दो से चार दिनों से लगातार</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectDuration('1 to 2 Weeks (1 से 2 हफ़्तों से)')">
          <div class="symptom-icon">🗓️</div>
          <div>
            <div class="symptom-name">1 to 2 Weeks</div>
            <div class="symptom-desc">पिछले एक या दो हफ़्तों से</div>
          </div>
        </button>

        <button type="button" class="symptom-tile" onclick="selectDuration('More than 1 Month (एक महीने से अधिक)')">
          <div class="symptom-icon">⏳</div>
          <div>
            <div class="symptom-name">Long-standing (&gt; 1 Month)</div>
            <div class="symptom-desc">काफी लंबे समय से चला आ रहा</div>
          </div>
        </button>
      </div>
    `;
    speakCurrentText(p.step3_title);

  // STEP 4: Clinical Follow-up 1 (Associated Symptoms & Radiation)
  } else if (step === 4) {
    let questionText = p.step4_other;
    if (intakeAnswers.symptom.includes("Chest")) questionText = p.step4_chest;
    else if (intakeAnswers.symptom.includes("Stomach")) questionText = p.step4_stomach;
    else if (intakeAnswers.symptom.includes("Fever")) questionText = p.step4_fever;
    else if (intakeAnswers.symptom.includes("Headache")) questionText = p.step4_head;
    else if (intakeAnswers.symptom.includes("Joint")) questionText = p.step4_joint;

    header.textContent = `Question 4: ${p.step4_title}`;
    renderYesNoQuestion(questionText, "Associated Signs / साथ में अन्य लक्षण:", "followup1");

  // STEP 5: Clinical Follow-up 2 (Triggers, Red Flags & Past Episodes)
  } else if (step === 5) {
    let questionText = p.step5_other;
    if (intakeAnswers.symptom.includes("Chest")) questionText = p.step5_chest;
    else if (intakeAnswers.symptom.includes("Stomach")) questionText = p.step5_stomach;
    else if (intakeAnswers.symptom.includes("Fever")) questionText = p.step5_fever;
    else if (intakeAnswers.symptom.includes("Headache")) questionText = p.step5_head;
    else if (intakeAnswers.symptom.includes("Joint")) questionText = p.step5_joint;

    header.textContent = `Question 5: ${p.step5_title}`;
    renderYesNoQuestion(questionText, "Triggers & Alarms / बढ़ने के कारण व पूर्व इतिहास:", "followup2");

  // STEP 6: Past Medical History - Sugar (Diabetes)
  } else if (step === 6) {
    header.textContent = `Question 6: ${p.step6_title}`;
    renderYesNoQuestion(p.step6_title, p.step6_sub, "sugar");

  // STEP 7: Past Medical History - High Blood Pressure (BP) / Heart Condition
  } else if (step === 7) {
    header.textContent = `Question 7: ${p.step7_title}`;
    renderYesNoQuestion(p.step7_title, p.step7_sub, "bp");

  // STEP 8: OPTIONAL PAST MEDICAL HISTORY & LAB REPORT UPLOAD
  } else if (step === 8) {
    header.textContent = `Question 8: ${p.step8_title}`;
    container.innerHTML = `
      <div class="pointer-question-prompt">
        <div class="pointer-title-main">${p.step8_title}</div>
        <div class="pointer-title-sub">${p.step8_sub}</div>
      </div>

      <!-- Upload Dropzone (Optional) -->
      <div class="upload-box-wrap" onclick="document.getElementById('docFileInput').click()">
        <input type="file" id="docFileInput" style="display:none;" accept="image/*,.pdf" onchange="handleDocumentUpload(event)">
        <div class="upload-box-icon">📤</div>
        <h4 style="font-size:1rem; font-weight:700; color:var(--teal); margin-bottom:0.35rem;">
          Click or Tap to Upload Lab Report / Prescription / Discharge Summary
        </h4>
        <p style="font-size:0.8rem; color:var(--text-muted); margin:0;">
          Supports Mobile Camera Photos, JPEG, PNG or PDF (Upload is Optional / ऐच्छिक)
        </p>
      </div>

      <!-- Preview if uploaded -->
      <div id="uploadedDocPreview"></div>

      <!-- Big Skip Button for Patients Without Reports -->
      <div style="margin-top:1.25rem; text-align:center;">
        <button type="button" class="btn btn-outline btn-block" style="padding:0.85rem; font-size:0.95rem; font-weight:700; border:2px dashed #94a3b8;" onclick="skipDocumentUpload()">
          ${p.skip_doc} ➔
        </button>
        <p style="font-size:0.75rem; color:var(--text-muted); margin-top:0.35rem;">
          ${p.skip_sub}
        </p>
      </div>
    `;
    speakCurrentText(p.step8_title);

  // STEP 9: Daily Medications & Painkillers
  } else if (step === 9) {
    header.textContent = `Question 9: ${p.step9_title}`;
    renderYesNoQuestion(p.step9_title, p.step9_sub, "meds");

  // STEP 10: Known Drug Allergies
  } else if (step === 10) {
    header.textContent = `Question 10: ${p.step10_title}`;
    renderYesNoQuestion(p.step10_title, p.step10_sub, "allergy");

  // STEP 11: Family History & Lifestyle Risk
  } else if (step === 11) {
    header.textContent = `Question 11: ${p.step11_title}`;
    renderYesNoQuestion(p.step11_title, p.step11_sub, "lifestyle");
  }
}

// Handlers for step choices
function selectSymptom(symptomText, icon, severity) {
  intakeAnswers.symptom = symptomText;
  intakeAnswers.symptom_icon = icon;
  intakeAnswers.triage = severity;

  patientTranscriptLog.push({ sender: "ai", text: POINTER_PROMPTS[currentLanguage].step1_title });
  patientTranscriptLog.push({ sender: "patient", text: `${icon} Selected: ${symptomText}` });

  document.getElementById("liveCC").textContent = symptomText;
  
  const triageBadge = document.getElementById("pointerTriageBadge");
  triageBadge.className = "badge-triage";
  if (severity === "Emergency") {
    triageBadge.classList.add("triage-emergency");
    triageBadge.textContent = "Emergency";
  } else if (severity === "Priority") {
    triageBadge.classList.add("triage-priority");
    triageBadge.textContent = "Priority";
  } else {
    triageBadge.classList.add("triage-routine");
    triageBadge.textContent = "Routine";
  }

  renderPointerQuestion(2);
}

function selectIntensity(intensityText) {
  intakeAnswers.intensity = intensityText;
}

function selectCharacter(charText) {
  intakeAnswers.character = charText;
  const combined = `${intakeAnswers.intensity || 'Moderate'} • ${charText}`;
  document.getElementById("liveCC").textContent = `${intakeAnswers.symptom} (${charText})`;

  patientTranscriptLog.push({ sender: "ai", text: POINTER_PROMPTS[currentLanguage].step2_title });
  patientTranscriptLog.push({ sender: "patient", text: `Intensity & Character: ${combined}` });

  renderPointerQuestion(3);
}

function selectDuration(durationText) {
  intakeAnswers.duration = durationText;
  document.getElementById("liveDuration").textContent = `${intakeAnswers.intensity || ''} • ${durationText}`;

  patientTranscriptLog.push({ sender: "ai", text: POINTER_PROMPTS[currentLanguage].step3_title });
  patientTranscriptLog.push({ sender: "patient", text: `Duration: ${durationText}` });

  renderPointerQuestion(4);
}

function renderYesNoQuestion(title, sub, fieldType) {
  const container = document.getElementById("pointerQuestionBox");
  const p = POINTER_PROMPTS[currentLanguage] || POINTER_PROMPTS.en;

  container.innerHTML = `
    <div class="pointer-question-prompt">
      <div class="pointer-title-main">${title}</div>
      <div class="pointer-title-sub">${sub}</div>
    </div>

    <div class="yes-no-wrap">
      <button type="button" class="btn-pointer-choice btn-pointer-yes" onclick="answerPointerYesNo('${fieldType}', true)">
        <span class="choice-icon">👍</span>
        <span class="choice-label">${p.yes_text}</span>
        <span class="choice-sub">${p.yes_sub}</span>
      </button>

      <button type="button" class="btn-pointer-choice btn-pointer-no" onclick="answerPointerYesNo('${fieldType}', false)">
        <span class="choice-icon">👎</span>
        <span class="choice-label">${p.no_text}</span>
        <span class="choice-sub">${p.no_sub}</span>
      </button>
    </div>

    <div style="text-align:center; margin-top:0.75rem;">
      <button type="button" class="speaker-btn" onclick="speakCurrentText('${title.replace(/'/g, "\\'")}')">
        🔊 Tap here to hear question aloud / बोलकर सुनें
      </button>
    </div>
  `;

  speakCurrentText(title);
}

function answerPointerYesNo(fieldType, answerBool) {
  const p = POINTER_PROMPTS[currentLanguage] || POINTER_PROMPTS.en;
  const ansLabel = answerBool ? p.yes_text : p.no_text;

  if (fieldType === "followup1") {
    intakeAnswers.clinical_followup_val = answerBool;
    intakeAnswers.clinical_followup = answerBool ? "Positive for associated radiation/symptoms" : "Negative for radiation";
    document.getElementById("liveClinicalFollowup").textContent = answerBool ? "⚠️ Positive Associated Signs" : "None";
    patientTranscriptLog.push({ sender: "ai", text: p.step4_title });
    patientTranscriptLog.push({ sender: "patient", text: `Associated Signs: ${ansLabel}` });
    renderPointerQuestion(5);

  } else if (fieldType === "followup2") {
    intakeAnswers.clinical_followup2_val = answerBool;
    intakeAnswers.clinical_followup2 = answerBool ? "Positive for exertion trigger / prior episodes" : "Negative for exertion trigger / prior episodes";
    const existing = document.getElementById("liveClinicalFollowup").textContent;
    document.getElementById("liveClinicalFollowup").textContent = `${existing} | ${answerBool ? '⚠️ Trigger/Past positive' : 'Clean'}`;
    patientTranscriptLog.push({ sender: "ai", text: p.step5_title });
    patientTranscriptLog.push({ sender: "patient", text: `Triggers / Past Episodes: ${ansLabel}` });
    renderPointerQuestion(6);

  } else if (fieldType === "sugar") {
    intakeAnswers.is_sugar_patient = answerBool;
    patientTranscriptLog.push({ sender: "ai", text: p.step6_title });
    patientTranscriptLog.push({ sender: "patient", text: `Sugar (Diabetes): ${ansLabel}` });
    updateSugarBPSummary();
    renderPointerQuestion(7);

  } else if (fieldType === "bp") {
    intakeAnswers.is_bp_patient = answerBool;
    patientTranscriptLog.push({ sender: "ai", text: p.step7_title });
    patientTranscriptLog.push({ sender: "patient", text: `High BP / Heart: ${ansLabel}` });
    updateSugarBPSummary();
    renderPointerQuestion(8); // Go to Optional Past Medical History Upload

  } else if (fieldType === "meds") {
    intakeAnswers.is_daily_meds = answerBool;
    patientTranscriptLog.push({ sender: "ai", text: p.step9_title });
    patientTranscriptLog.push({ sender: "patient", text: `Daily Medicines / Painkillers: ${ansLabel}` });
    document.getElementById("liveMeds").textContent = answerBool ? "Takes daily painkillers / regular tablets" : "None reported";

    checkClinicalContradictions();
    renderPointerQuestion(10);

  } else if (fieldType === "allergy") {
    intakeAnswers.is_allergic = answerBool;
    patientTranscriptLog.push({ sender: "ai", text: p.step10_title });
    patientTranscriptLog.push({ sender: "patient", text: `Drug Allergies: ${ansLabel}` });
    document.getElementById("liveAllergy").textContent = answerBool ? "⚠️ Has Known Drug Allergies (Penicillin/Sulfa)" : "No Known Drug Allergies (NKDA)";

    checkClinicalContradictions();
    renderPointerQuestion(11);

  } else if (fieldType === "lifestyle") {
    intakeAnswers.family_lifestyle = answerBool;
    patientTranscriptLog.push({ sender: "ai", text: p.step11_title });
    patientTranscriptLog.push({ sender: "patient", text: `Family History / Tobacco: ${ansLabel}` });
    document.getElementById("liveLifestyle").textContent = answerBool ? "Positive Family / Lifestyle Risk" : "Negative / Standard";

    checkClinicalContradictions();
    showIntakeCompletion();
  }
}

function updateSugarBPSummary() {
  const s = intakeAnswers.is_sugar_patient ? "Sugar: YES" : "Sugar: NO";
  const b = intakeAnswers.is_bp_patient ? "BP: YES" : "BP: NO";
  document.getElementById("liveSugarBP").textContent = `${s} | ${b}`;
}

// ==============================================================================
// OPTIONAL PAST MEDICAL HISTORY & LAB REPORT UPLOAD
// ==============================================================================
function handleDocumentUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    intakeAnswers.has_documents = true;
    intakeAnswers.doc_name = file.name;
    intakeAnswers.doc_data = e.target.result;

    const previewDiv = document.getElementById("uploadedDocPreview");
    previewDiv.innerHTML = `
      <div class="upload-preview-card">
        <div style="display:flex; align-items:center; gap:0.75rem;">
          ${file.type.startsWith("image/") ? `<img src="${e.target.result}" class="upload-preview-thumb">` : `<span style="font-size:2rem;">📄</span>`}
          <div>
            <strong style="color:var(--teal); font-size:0.875rem;">${escapeHtml(file.name)}</strong><br>
            <span style="font-size:0.75rem; color:var(--text-muted);">${(file.size / 1024).toFixed(1)} KB • Verified Attachment</span>
          </div>
        </div>
        <span class="doc-badge-chip">✓ Attached</span>
      </div>
      <div style="margin-top:1rem; text-align:center;">
        <button type="button" class="btn btn-teal" style="padding:0.75rem 1.5rem; font-weight:700;" onclick="renderPointerQuestion(9)">
          Continue to Step 9 (अगले प्रश्न पर जाएं) ➔
        </button>
      </div>
    `;

    document.getElementById("liveDocuments").innerHTML = `
      <span style="color:#0d9488; font-weight:700;">📄 ${escapeHtml(file.name)}</span>
    `;

    patientTranscriptLog.push({ sender: "ai", text: "Past Medical Records / Prescription Upload" });
    patientTranscriptLog.push({ sender: "patient", text: `Uploaded Document: ${file.name} (${(file.size / 1024).toFixed(1)} KB)` });
    speakCurrentText("Report uploaded successfully. You can continue to the next step.");
  };

  reader.readAsDataURL(file);
}

function skipDocumentUpload() {
  intakeAnswers.has_documents = false;
  intakeAnswers.doc_name = "";
  intakeAnswers.doc_data = "";

  document.getElementById("liveDocuments").textContent = "None (Skipped)";

  patientTranscriptLog.push({ sender: "ai", text: "Past Medical Records / Prescription Upload" });
  patientTranscriptLog.push({ sender: "patient", text: "Skipped (No prior records available)" });

  renderPointerQuestion(9);
}

// ==============================================================================
// CONTRADICTION & GAP DETECTION LOGIC
// ==============================================================================
function checkClinicalContradictions() {
  detectedContradictions = [];

  // Contradiction 1: Stomach burning + taking daily painkillers (NSAID ulcer risk)
  if (intakeAnswers.symptom.includes("Stomach") && intakeAnswers.is_daily_meds === true) {
    detectedContradictions.push({
      severity: "high",
      title: "NSAID-Induced Peptic Ulcer Contradiction",
      desc: "Patient has epigastric stomach burning while taking daily painkillers (e.g. Ibuprofen), which strips gastric mucosal lining and triggers ulcers."
    });
  }

  // Contradiction 2: Chest pain + BP patient + taking NO regular medications
  if (intakeAnswers.symptom.includes("Chest") && intakeAnswers.is_bp_patient === true && intakeAnswers.is_daily_meds === false) {
    detectedContradictions.push({
      severity: "high",
      title: "Unmanaged Cardiac Risk Contradiction",
      desc: "Patient reports acute chest pain with documented high blood pressure, but reports taking zero daily antihypertensive maintenance medicines."
    });
  }

  // Contradiction 3: Documented allergy alert
  if (intakeAnswers.is_allergic === true) {
    detectedContradictions.push({
      severity: "high",
      title: "Contraindicated Drug Allergy Alert",
      desc: "Patient flagged known adverse reaction to medicines. Doctor must cross-check antibiotic and painkiller prescription."
    });
  }

  updateContradictionUI();
}

function updateContradictionUI() {
  const container = document.getElementById("pointerFlagsContainer");
  const countBadge = document.getElementById("pointerFlagCount");

  countBadge.textContent = `${detectedContradictions.length} Flag(s)`;

  if (detectedContradictions.length === 0) {
    container.innerHTML = `
      <div style="font-size:0.8rem; color:#16a34a; padding:0.4rem 0;">
        ✓ No contradictions detected in current pointer answers.
      </div>
    `;
  } else {
    let html = "";
    detectedContradictions.forEach(c => {
      html += `
        <div class="flag-item danger">
          <strong>⚠️ ${escapeHtml(c.title)}</strong><br>
          ${escapeHtml(c.desc)}
        </div>
      `;
    });
    container.innerHTML = html;
  }
}

function showIntakeCompletion() {
  const container = document.getElementById("pointerQuestionBox");
  const header = document.getElementById("pointerStepHeader");
  header.textContent = "✅ Clinical Intake Complete!";

  container.innerHTML = `
    <div style="text-align:center; padding:1.5rem 1rem;">
      <div style="font-size:3rem; margin-bottom:0.5rem;">🎉</div>
      <h3 style="font-size:1.25rem; color:var(--primary); font-weight:700;">
        All 11 Questions Answered!
      </h3>
      <p style="font-size:0.875rem; color:var(--text-muted); margin:0.5rem auto 1.5rem auto; max-width:460px;">
        सभी 11 सवालों के जवाब और मेडिकल रिपोर्ट सफलतापूर्वक दर्ज हो चुके हैं। आपकी केस हिस्ट्री डॉक्टर के पास समीक्षा के लिए तैयार है।
      </p>

      <button type="button" class="btn btn-teal" style="padding:0.85rem 1.75rem; font-size:1rem; font-weight:700;" onclick="finalizeAndSubmitIntake()">
        🚀 Submit to Doctor Now / डॉक्टर को भेजें ➔
      </button>
    </div>
  `;

  document.getElementById("finalSubmitBtn").disabled = false;
  speakCurrentText("Your health intake is complete. Please tap submit to send your case to the doctor.");
}

function updateStepperIndicator(step) {
  document.getElementById("intakeProgressBadge").textContent = `Step ${step} of ${TOTAL_POINTER_STEPS}`;
  for (let i = 1; i <= TOTAL_POINTER_STEPS; i++) {
    const dot = document.getElementById(`dot${i}`);
    if (!dot) continue;
    dot.className = "step-dot";
    if (i < step) dot.classList.add("completed");
    else if (i === step) dot.classList.add("active");
  }
}

// ==============================================================================
// SUBMIT INTAKE TO DOCTOR (DO NOT JUMP TO DOCTOR - SHOW LOCALIZED THANK YOU)
// ==============================================================================
async function finalizeAndSubmitIntake() {
  const caseId = `CAS-2026-${Math.floor(10000 + Math.random() * 90000)}`;
  const triageLevel = intakeAnswers.triage || "Routine";

  const newCase = {
    id: caseId,
    patient_name: activePatient.name,
    age: activePatient.age,
    gender: activePatient.gender,
    contact: activePatient.phone,
    language: (activePatient.language || currentLanguage || "hi").toUpperCase(),
    chief_complaint: `${intakeAnswers.symptom} (${intakeAnswers.character || 'Acute'})`,
    symptoms: `${intakeAnswers.symptom}. Intensity: ${intakeAnswers.intensity || 'Moderate'}.`,
    hpi: `Patient presented with ${intakeAnswers.symptom}. Duration: ${intakeAnswers.duration || 'Not specified'}. Associated signs: ${intakeAnswers.clinical_followup || 'None'}. Triggers/Past: ${intakeAnswers.clinical_followup2 || 'None'}. Diabetic: ${intakeAnswers.is_sugar_patient ? 'Yes' : 'No'}. Hypertensive: ${intakeAnswers.is_bp_patient ? 'Yes' : 'No'}.`,
    past_history: `Diabetes: ${intakeAnswers.is_sugar_patient ? 'Positive' : 'Negative'} | Hypertension: ${intakeAnswers.is_bp_patient ? 'Positive' : 'Negative'} | Attached Records: ${intakeAnswers.has_documents ? intakeAnswers.doc_name : 'None'}`,
    medications: intakeAnswers.is_daily_meds ? "Takes daily pain relief / maintenance tablets" : "None reported",
    allergies: intakeAnswers.is_allergic ? "Flagged known drug allergies" : "No known drug allergies (NKDA)",
    lifestyle: intakeAnswers.family_lifestyle ? "Positive family cardiac history / tobacco consumption" : "Standard non-contributory",
    triage_level: triageLevel,
    contradictions: detectedContradictions,
    missing_gaps: [],
    uploaded_document_name: intakeAnswers.doc_name,
    uploaded_document_data: intakeAnswers.doc_data,
    doctor_status: "Pending Review",
    doctor_notes: "",
    doctor_diagnosis: "",
    doctor_rx: "",
    verified_by: "",
    verified_at: "",
    conversation_transcript: patientTranscriptLog,
    created_at: new Date().toISOString().replace("T", " ").slice(0, 19)
  };

  await saveCaseToDatabase(newCase);

  // Show localized Thank You message in selected language & 10-second countdown
  showThankYouScreen(caseId);
}

async function saveCaseToDatabase(newCase) {
  try {
    await fetch("/api/cases", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newCase)
    });
  } catch (err) {
    console.log("Local fallback save:", err.message);
  }

  const idx = allCases.findIndex(c => c.id === newCase.id);
  if (idx >= 0) allCases[idx] = newCase;
  else allCases.unshift(newCase);

  localStorage.setItem("patientcare_cases", JSON.stringify(allCases));
  updateDoctorStats();
  renderCasesTable(allCases);
}

// ==============================================================================
// LOCALIZED THANK YOU & PATIENT WAITING SCREEN (IN SELECTED LANGUAGE)
// ==============================================================================
function showThankYouScreen(caseId) {
  const container = document.getElementById("pointerQuestionBox");
  const header = document.getElementById("pointerStepHeader");
  
  // Pick prompts in user's selected language during registration
  const lang = activePatient.language || currentLanguage || "en";
  const p = POINTER_PROMPTS[lang] || POINTER_PROMPTS.en;

  header.textContent = `✅ ${p.thank_you_title}`;

  // Hide the voice bar during thank you screen
  const voiceBar = document.querySelector(".voice-illiterate-bar");
  if (voiceBar) voiceBar.style.display = "none";

  let seconds = 10;

  // Speak thank-you voice narration in the selected language
  speakCurrentText(p.spoken_thank_you);

  container.innerHTML = `
    <div class="thankyou-card">
      <div class="thankyou-icon-wrap">🙏</div>
      <div class="token-badge-large">
        <span>🎫 TOKEN ID:</span>
        <span>${escapeHtml(caseId)}</span>
      </div>
      <h2 style="font-size:1.4rem; font-weight:800; color:var(--primary); margin:0 0 0.5rem 0;">
        ${escapeHtml(p.thank_you_title)}, ${escapeHtml(activePatient.name)}!
      </h2>
      <p style="font-size:0.95rem; color:var(--text-main); font-weight:600; margin:0 0 1rem 0;">
        ${escapeHtml(p.thank_you_sub)}
      </p>

      <div class="patient-wait-box">
        <div style="font-size:1rem; font-weight:700; color:var(--teal); margin-bottom:0.25rem;">
          📢 ${escapeHtml(p.wait_heading)}
        </div>
        <div style="font-size:0.9rem; color:var(--text-main); line-height:1.4;">
          ${escapeHtml(p.wait_msg)}
        </div>
      </div>

      <div class="countdown-box">
        <div style="font-size:0.8rem; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.5px;">
          ${escapeHtml(p.redirect_msg)}
        </div>
        <div class="countdown-number" id="thankYouCountdownNum">${seconds}</div>
        <div class="countdown-bar-wrap">
          <div class="countdown-bar-fill" id="countdownProgressBar" style="width: 100%;"></div>
        </div>
        <div style="font-size:0.75rem; color:var(--text-muted);">
          seconds
        </div>
      </div>

      <div style="margin-top:1.25rem;">
        <button type="button" class="btn btn-teal" style="padding:0.75rem 1.75rem; font-weight:700; font-size:0.9rem;" onclick="resetForNewPatient()">
          ${escapeHtml(p.next_patient_btn)}
        </button>
      </div>
    </div>
  `;

  if (thankYouCountdownTimer) clearInterval(thankYouCountdownTimer);

  thankYouCountdownTimer = setInterval(() => {
    seconds--;
    const numEl = document.getElementById("thankYouCountdownNum");
    const barEl = document.getElementById("countdownProgressBar");
    if (numEl) numEl.textContent = seconds;
    if (barEl) barEl.style.width = `${(seconds / 10) * 100}%`;

    if (seconds <= 0) {
      clearInterval(thankYouCountdownTimer);
      thankYouCountdownTimer = null;
      resetForNewPatient();
    }
  }, 1000);
}

function resetForNewPatient() {
  if (thankYouCountdownTimer) {
    clearInterval(thankYouCountdownTimer);
    thankYouCountdownTimer = null;
  }
  if (window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }

  // Restore voice bar display
  const voiceBar = document.querySelector(".voice-illiterate-bar");
  if (voiceBar) voiceBar.style.display = "flex";

  // Reset internal intake state
  currentPointerStep = 1;
  patientTranscriptLog = [];
  detectedContradictions = [];
  intakeAnswers = {
    symptom: "",
    symptom_icon: "",
    triage: "Routine",
    intensity: "",
    character: "",
    duration: "",
    clinical_followup: "",
    clinical_followup_val: null,
    clinical_followup2: "",
    clinical_followup2_val: null,
    is_sugar_patient: null,
    is_bp_patient: null,
    has_documents: false,
    doc_name: "",
    doc_data: "",
    is_daily_meds: null,
    meds_detail: "",
    is_allergic: null,
    allergy_detail: "",
    family_lifestyle: null
  };

  // Clear registration form inputs for the new patient
  const nameEl = document.getElementById("regName");
  const ageEl = document.getElementById("regAge");
  const phoneEl = document.getElementById("regPhone");
  if (nameEl) nameEl.value = "";
  if (ageEl) ageEl.value = "";
  if (phoneEl) phoneEl.value = "";

  // Reset live sidebar indicators
  const ccEl = document.getElementById("liveCC");
  const durEl = document.getElementById("liveDuration");
  const followEl = document.getElementById("liveClinicalFollowup");
  const sugarBPEl = document.getElementById("liveSugarBP");
  const docsEl = document.getElementById("liveDocuments");
  const medsEl = document.getElementById("liveMeds");
  const allergyEl = document.getElementById("liveAllergy");
  const lifeEl = document.getElementById("liveLifestyle");
  const submitBtn = document.getElementById("finalSubmitBtn");

  if (ccEl) ccEl.textContent = "Waiting for symptom selection...";
  if (durEl) durEl.textContent = "Not answered yet";
  if (followEl) followEl.textContent = "None reported";
  if (sugarBPEl) sugarBPEl.textContent = "Negative / None";
  if (docsEl) docsEl.textContent = "No documents attached (Optional)";
  if (medsEl) medsEl.textContent = "None reported";
  if (allergyEl) allergyEl.textContent = "None";
  if (lifeEl) lifeEl.textContent = "Standard / Non-contributory";
  if (submitBtn) submitBtn.disabled = true;

  updateContradictionUI();

  // Return to Patient Registration Form
  document.getElementById("pointerIntakeView").classList.remove("active");
  document.getElementById("doctorView").classList.remove("active");
  document.getElementById("registrationView").classList.add("active");

  const p = POINTER_PROMPTS[currentLanguage] || POINTER_PROMPTS.en;
  speakCurrentText(p.regWelcome);
}

// ==============================================================================
// DOCTOR PORTAL & MODALS
// ==============================================================================
function openDoctorLoginModal() {
  document.getElementById("doctorLoginModal").classList.add("active");
}

function closeDoctorLoginModal() {
  document.getElementById("doctorLoginModal").classList.remove("active");
}

function handleDoctorLogin(e) {
  e.preventDefault();
  closeDoctorLoginModal();
  switchRole("doctor");
}

function quickDemoDoctorLogin() {
  closeDoctorLoginModal();
  switchRole("doctor");
}

function switchRole(role) {
  currentRole = role;
  if (role === "doctor") {
    document.getElementById("registrationView").classList.remove("active");
    document.getElementById("pointerIntakeView").classList.remove("active");
    document.getElementById("doctorView").classList.add("active");
    loadStoredCases();
  } else {
    document.getElementById("doctorView").classList.remove("active");
    document.getElementById("registrationView").classList.add("active");
  }
}

function updateDoctorStats() {
  const total = allCases.length;
  const pending = allCases.filter(c => c.doctor_status !== "Verified").length;
  const flagged = allCases.filter(c => c.contradictions && c.contradictions.length > 0).length;
  const verified = allCases.filter(c => c.doctor_status === "Verified").length;

  document.getElementById("statTotalCases").textContent = total;
  document.getElementById("statPendingCases").textContent = pending;
  document.getElementById("statFlaggedCases").textContent = flagged;
  document.getElementById("statVerifiedCases").textContent = verified;
  document.getElementById("headerPendingBadge").textContent = pending;
}

let activeDoctorFilter = "all";

function setDoctorFilter(filter, btn) {
  activeDoctorFilter = filter;
  document.querySelectorAll(".filter-tab").forEach(t => t.classList.remove("active"));
  btn.classList.add("active");
  filterCasesTable();
}

function filterCasesTable() {
  const search = document.getElementById("doctorSearchInput").value.toLowerCase();
  
  const filtered = allCases.filter(c => {
    const matchSearch = (
      c.patient_name.toLowerCase().includes(search) ||
      c.id.toLowerCase().includes(search) ||
      c.chief_complaint.toLowerCase().includes(search)
    );
    if (!matchSearch) return false;

    if (activeDoctorFilter === "pending") return c.doctor_status !== "Verified";
    if (activeDoctorFilter === "flagged") return (c.contradictions && c.contradictions.length > 0);
    if (activeDoctorFilter === "verified") return c.doctor_status === "Verified";
    return true;
  });

  renderCasesTable(filtered);
}

function renderCasesTable(cases) {
  const tbody = document.getElementById("casesTableBody");
  tbody.innerHTML = "";

  if (cases.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">
          No patient records found matching criteria.
        </td>
      </tr>
    `;
    return;
  }

  cases.forEach(c => {
    const tr = document.createElement("tr");

    let triageClass = "triage-routine";
    if (c.triage_level.includes("Emergency")) triageClass = "triage-emergency";
    else if (c.triage_level.includes("Priority")) triageClass = "triage-priority";

    const numFlags = (c.contradictions ? c.contradictions.length : 0);
    const flagHtml = numFlags > 0
      ? `<span class="status-badge" style="background:#fee2e2; color:#dc2626; border:1px solid #fca5a5;">⚠️ ${numFlags} Flag(s)</span>`
      : `<span class="status-badge" style="background:#f0fdf4; color:#16a34a; border:1px solid #bbf7d0;">✓ Clean</span>`;

    const statusHtml = c.doctor_status === "Verified"
      ? `<span class="status-badge status-verified">✅ Verified</span>`
      : `<span class="status-badge status-pending">⏳ Needs Review</span>`;

    const docChip = c.uploaded_document_name
      ? `<span style="font-size:0.7rem; color:var(--teal); font-weight:700; display:block;">📄 ${escapeHtml(c.uploaded_document_name.slice(0, 18))}</span>`
      : '';

    tr.innerHTML = `
      <td><strong>${escapeHtml(c.id)}</strong></td>
      <td>
        <strong>${escapeHtml(c.patient_name)}</strong><br>
        <span style="font-size:0.75rem; color:var(--text-muted);">${c.age} yrs • ${c.gender} • ${c.language || 'Hindi'}</span>
        ${docChip}
      </td>
      <td style="max-width:240px;">${escapeHtml(c.chief_complaint)}</td>
      <td><span class="badge-triage ${triageClass}">${escapeHtml(c.triage_level)}</span></td>
      <td>${flagHtml}</td>
      <td>${statusHtml}</td>
      <td>
        <button class="btn btn-primary" style="padding:0.35rem 0.75rem; font-size:0.775rem;" onclick="openCaseReview('${c.id}')">
          👁️ Review & Verify
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function openCaseReview(caseId) {
  const caseObj = allCases.find(c => c.id === caseId);
  if (!caseObj) return;

  activeCase = caseObj;

  document.getElementById("modalPatientTitle").textContent = `${caseObj.patient_name} (${caseObj.id})`;
  document.getElementById("modalPatientMeta").textContent = `${caseObj.age} Yrs • ${caseObj.gender} • Contact: ${caseObj.contact || 'N/A'} • Preferred: ${caseObj.language || 'Hindi'}`;

  const verifiedBanner = document.getElementById("verifiedBanner");
  if (caseObj.doctor_status === "Verified") {
    verifiedBanner.style.display = "flex";
    document.getElementById("verifiedByLabel").textContent = caseObj.verified_by || "Dr. Priya Sharma, M.D.";
    document.getElementById("verifiedAtLabel").textContent = `Verified: ${caseObj.verified_at || caseObj.created_at}`;
    document.getElementById("verifyBtn").textContent = "✓ Re-Verify Record";
  } else {
    verifiedBanner.style.display = "none";
    document.getElementById("verifyBtn").textContent = "✅ Verify & Sign-Off Record";
  }

  // Left Column: Patient Responses
  const transcriptBox = document.getElementById("modalTranscriptBox");
  transcriptBox.innerHTML = "";
  if (caseObj.conversation_transcript && caseObj.conversation_transcript.length > 0) {
    caseObj.conversation_transcript.forEach(msg => {
      const b = document.createElement("div");
      b.className = `chat-bubble-mini ${msg.sender}`;
      b.innerHTML = `<strong>${msg.sender === 'ai' ? '🩺 Question' : '👤 Patient'}:</strong> ${escapeHtml(msg.text)}`;
      transcriptBox.appendChild(b);
    });
  } else {
    transcriptBox.innerHTML = `<div style="font-size:0.8rem; color:var(--text-muted);">No transcript recorded for this patient.</div>`;
  }

  // Contradictions in Modal
  const flagsBox = document.getElementById("modalContradictionsBox");
  flagsBox.innerHTML = "";
  const allFlags = caseObj.contradictions || [];
  if (allFlags.length === 0) {
    flagsBox.innerHTML = `<div style="font-size:0.8rem; color:#16a34a;">No conflicting statements flagged.</div>`;
  } else {
    allFlags.forEach(f => {
      const div = document.createElement("div");
      div.className = `flag-item ${f.severity === 'high' ? 'danger' : 'warning'}`;
      div.innerHTML = `<strong>${escapeHtml(f.title)}:</strong> ${escapeHtml(f.desc)}`;
      flagsBox.appendChild(div);
    });
  }

  // Uploaded Document Viewer in Modal
  const docViewer = document.getElementById("modalDocumentViewer");
  if (docViewer) {
    if (caseObj.uploaded_document_name) {
      const isImg = caseObj.uploaded_document_data && caseObj.uploaded_document_data.startsWith("data:image");
      docViewer.innerHTML = `
        <div style="display:flex; align-items:center; gap:0.75rem; background:white; padding:0.5rem; border-radius:4px; border:1px solid #99f6e4;">
          ${isImg ? `<img src="${caseObj.uploaded_document_data}" style="max-width:50px; max-height:50px; border-radius:4px;">` : `<span style="font-size:1.5rem;">📄</span>`}
          <div>
            <strong style="color:var(--teal);">${escapeHtml(caseObj.uploaded_document_name)}</strong><br>
            <span style="font-size:0.75rem; color:#16a34a; font-weight:600;">✓ Document Verified by AI OCR</span>
          </div>
          ${caseObj.uploaded_document_data ? `<a href="${caseObj.uploaded_document_data}" target="_blank" class="btn btn-outline" style="margin-left:auto; padding:0.25rem 0.6rem; font-size:0.75rem;">View Document ↗</a>` : ''}
        </div>
      `;
    } else {
      docViewer.innerHTML = `<span style="font-style:italic; color:var(--text-muted);">No prior medical records or lab reports attached by patient.</span>`;
    }
  }

  // Right Column: Editable Fields
  document.getElementById("editCaseId").value = caseObj.id;
  document.getElementById("editCC").value = caseObj.chief_complaint || "";
  document.getElementById("editHPI").value = caseObj.hpi || "";
  document.getElementById("editPastHistory").value = caseObj.past_history || "None reported";
  document.getElementById("editMeds").value = caseObj.medications || "None reported";
  document.getElementById("editAllergies").value = caseObj.allergies || "NKDA";
  document.getElementById("editDiagnosis").value = caseObj.doctor_diagnosis || "";
  document.getElementById("editRx").value = caseObj.doctor_rx || "";
  document.getElementById("editDoctorNotes").value = caseObj.doctor_notes || "";

  document.getElementById("reviewModal").classList.add("active");
}

function closeReviewModal() {
  document.getElementById("reviewModal").classList.remove("active");
  activeCase = null;
}

async function saveCaseEditsOnly() {
  if (!activeCase) return;

  activeCase.chief_complaint = document.getElementById("editCC").value;
  activeCase.hpi = document.getElementById("editHPI").value;
  activeCase.past_history = document.getElementById("editPastHistory").value;
  activeCase.medications = document.getElementById("editMeds").value;
  activeCase.allergies = document.getElementById("editAllergies").value;
  activeCase.doctor_diagnosis = document.getElementById("editDiagnosis").value;
  activeCase.doctor_rx = document.getElementById("editRx").value;
  activeCase.doctor_notes = document.getElementById("editDoctorNotes").value;

  await saveCaseToDatabase(activeCase);
  alert("Case details updated successfully.");
}

async function verifyAndSignOffCase() {
  if (!activeCase) return;

  activeCase.chief_complaint = document.getElementById("editCC").value;
  activeCase.hpi = document.getElementById("editHPI").value;
  activeCase.past_history = document.getElementById("editPastHistory").value;
  activeCase.medications = document.getElementById("editMeds").value;
  activeCase.allergies = document.getElementById("editAllergies").value;
  activeCase.doctor_diagnosis = document.getElementById("editDiagnosis").value || "Clinical Diagnosis Confirmed";
  activeCase.doctor_rx = document.getElementById("editRx").value || "1. Tab Pantoprazole 40mg OD AC\n2. Symptomatic pain relief";
  activeCase.doctor_notes = document.getElementById("editDoctorNotes").value || "Patient verified and cleared for treatment.";
  activeCase.doctor_status = "Verified";
  activeCase.verified_by = "Dr. Priya Sharma, M.D. (Internal Medicine)";
  activeCase.verified_at = new Date().toISOString().replace("T", " ").slice(0, 19);

  try {
    await fetch(`/api/cases/${activeCase.id}/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        doctor_diagnosis: activeCase.doctor_diagnosis,
        doctor_rx: activeCase.doctor_rx,
        doctor_notes: activeCase.doctor_notes,
        verified_by: activeCase.verified_by
      })
    });
  } catch (err) {
    console.log("Local fallback verify:", err.message);
  }

  const idx = allCases.findIndex(c => c.id === activeCase.id);
  if (idx >= 0) allCases[idx] = activeCase;
  localStorage.setItem("patientcare_cases", JSON.stringify(allCases));

  updateDoctorStats();
  renderCasesTable(allCases);
  closeReviewModal();
  alert(`✅ Case ${activeCase.id} has been digitally verified and signed off by Dr. Priya Sharma, M.D.!`);
}

function printCaseSheet() {
  if (!activeCase) return;

  const container = document.getElementById("printHospitalSheet");
  container.innerHTML = `
    <div style="font-family:Arial, sans-serif; max-width:800px; margin:0 auto; padding:20px; border:2px solid #0d9488;">
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #0d9488; padding-bottom:10px; margin-bottom:15px;">
        <div>
          <h2 style="margin:0; color:#1e3a8a;">AIIMS / DISTRICT CIVIL HOSPITAL</h2>
          <p style="margin:2px 0 0 0; font-size:12px; color:#555;">Smart India Hackathon 2026 Prototype • Patient Care Case Sheet</p>
        </div>
        <div style="text-align:right;">
          <h3 style="margin:0; color:#0d9488;">Case ID: ${activeCase.id}</h3>
          <p style="margin:0; font-size:12px;">Date: ${activeCase.verified_at || activeCase.created_at}</p>
        </div>
      </div>

      <table style="width:100%; border-collapse:collapse; margin-bottom:15px; font-size:13px;">
        <tr style="background:#f1f5f9;">
          <td style="padding:6px; font-weight:bold;">Patient Name:</td>
          <td style="padding:6px;">${activeCase.patient_name}</td>
          <td style="padding:6px; font-weight:bold;">Age / Gender:</td>
          <td style="padding:6px;">${activeCase.age} yrs / ${activeCase.gender}</td>
        </tr>
        <tr>
          <td style="padding:6px; font-weight:bold;">Contact:</td>
          <td style="padding:6px;">${activeCase.contact || 'N/A'}</td>
          <td style="padding:6px; font-weight:bold;">Triage Priority:</td>
          <td style="padding:6px; font-weight:bold; color:#dc2626;">${activeCase.triage_level}</td>
        </tr>
      </table>

      <h3 style="color:#1e3a8a; border-bottom:1px solid #ccc; padding-bottom:4px; margin-top:15px; font-size:14px;">1. CHIEF COMPLAINT</h3>
      <p style="font-size:13px; margin:4px 0 12px 0;">${activeCase.chief_complaint}</p>

      <h3 style="color:#1e3a8a; border-bottom:1px solid #ccc; padding-bottom:4px; font-size:14px;">2. HISTORY OF PRESENT ILLNESS (HPI)</h3>
      <p style="font-size:13px; margin:4px 0 12px 0;">${activeCase.hpi || 'None recorded'}</p>

      <h3 style="color:#1e3a8a; border-bottom:1px solid #ccc; padding-bottom:4px; font-size:14px;">3. PAST MEDICAL HISTORY & LAB DOCUMENTS</h3>
      <p style="font-size:13px; margin:4px 0 6px 0;"><strong>Past History:</strong> ${activeCase.past_history || 'None'}</p>
      <p style="font-size:13px; margin:4px 0 6px 0;"><strong>Attached Reports:</strong> ${activeCase.uploaded_document_name || 'None'}</p>
      <p style="font-size:13px; margin:4px 0 6px 0;"><strong>Medications:</strong> ${activeCase.medications || 'None'}</p>
      <p style="font-size:13px; margin:4px 0 12px 0;"><strong>Allergies:</strong> <span style="color:#dc2626; font-weight:bold;">${activeCase.allergies || 'NKDA'}</span></p>

      <h3 style="color:#1e3a8a; border-bottom:1px solid #ccc; padding-bottom:4px; font-size:14px;">4. PROVISIONAL DIAGNOSIS & PRESCRIPTION</h3>
      <p style="font-size:13px; margin:4px 0 6px 0;"><strong>Diagnosis:</strong> ${activeCase.doctor_diagnosis || 'Pending'}</p>
      <div style="background:#f8fafc; border:1px solid #e2e8f0; padding:8px; border-radius:4px; font-size:13px; white-space:pre-line;">
        <strong>Rx / Orders:</strong>\n${activeCase.doctor_rx || 'Standard symptomatic management.'}
      </div>

      <div style="margin-top:40px; display:flex; justify-content:space-between; align-items:flex-end;">
        <div>
          <p style="font-size:11px; color:#666;">Generated via AI-Assisted Patient Intake. Verified by registered physician.</p>
        </div>
        <div style="text-align:center; border-top:1px solid #000; padding-top:5px; width:250px;">
          <p style="font-size:13px; font-weight:bold; margin:0;">${activeCase.verified_by || 'Dr. Priya Sharma, M.D.'}</p>
          <p style="font-size:11px; color:#555; margin:0;">Verified Medical Practitioner</p>
        </div>
      </div>
    </div>
  `;

  window.print();
}

// ==============================================================================
// AUDIO READ-ALOUD & VOICE ACCESSIBILITY (FOR ILLITERATE PATIENTS)
// ==============================================================================
function toggleAudioNarration() {
  isAudioAssistanceOn = !isAudioAssistanceOn;
  const btn = document.getElementById("globalAudioToggleBtn");
  const text = document.getElementById("audioText");
  const icon = document.getElementById("audioIcon");

  if (isAudioAssistanceOn) {
    btn.style.background = "#f0fdf4";
    btn.style.borderColor = "#bbf7d0";
    btn.style.color = "#166534";
    icon.textContent = "🔊";
    text.innerHTML = "Voice Assistance: <strong>ON</strong>";
    speakCurrentText("Voice assistance is enabled.");
  } else {
    btn.style.background = "#f1f5f9";
    btn.style.borderColor = "#cbd5e1";
    btn.style.color = "#64748b";
    icon.textContent = "🔇";
    text.innerHTML = "Voice Assistance: <strong>OFF</strong>";
    if (window.speechSynthesis) window.speechSynthesis.cancel();
  }
}

function speakCurrentText(textToSpeak) {
  if (!isAudioAssistanceOn) return;
  if (!("speechSynthesis" in window)) return;

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(textToSpeak);
  const voiceLangMap = {
    en: "en-IN",
    hi: "hi-IN",
    ta: "ta-IN",
    te: "te-IN",
    bn: "bn-IN",
    mr: "mr-IN",
    gu: "gu-IN"
  };
  const activeLang = (activePatient && activePatient.language) ? activePatient.language : currentLanguage;
  utterance.lang = voiceLangMap[activeLang] || "en-IN";
  utterance.rate = 0.95;

  window.speechSynthesis.speak(utterance);
}

function speakActiveQuestion() {
  const p = POINTER_PROMPTS[currentLanguage] || POINTER_PROMPTS.en;
  if (currentPointerStep === 1) speakCurrentText(p.step1_title);
  else if (currentPointerStep === 2) speakCurrentText(p.step2_title);
  else if (currentPointerStep === 3) speakCurrentText(p.step3_title);
  else if (currentPointerStep === 4) {
    let q = p.step4_other;
    if (intakeAnswers.symptom.includes("Chest")) q = p.step4_chest;
    else if (intakeAnswers.symptom.includes("Stomach")) q = p.step4_stomach;
    else if (intakeAnswers.symptom.includes("Fever")) q = p.step4_fever;
    else if (intakeAnswers.symptom.includes("Headache")) q = p.step4_head;
    else if (intakeAnswers.symptom.includes("Joint")) q = p.step4_joint;
    speakCurrentText(q);
  }
  else if (currentPointerStep === 5) {
    let q = p.step5_other;
    if (intakeAnswers.symptom.includes("Chest")) q = p.step5_chest;
    else if (intakeAnswers.symptom.includes("Stomach")) q = p.step5_stomach;
    else if (intakeAnswers.symptom.includes("Fever")) q = p.step5_fever;
    else if (intakeAnswers.symptom.includes("Headache")) q = p.step5_head;
    else if (intakeAnswers.symptom.includes("Joint")) q = p.step5_joint;
    speakCurrentText(q);
  }
  else if (currentPointerStep === 6) speakCurrentText(p.step6_title);
  else if (currentPointerStep === 7) speakCurrentText(p.step7_title);
  else if (currentPointerStep === 8) speakCurrentText(p.step8_title);
  else if (currentPointerStep === 9) speakCurrentText(p.step9_title);
  else if (currentPointerStep === 10) speakCurrentText(p.step10_title);
  else if (currentPointerStep === 11) speakCurrentText(p.step11_title);
}

function initVoiceRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) return;

  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    isRecording = true;
    const btn = document.getElementById("pointerMicBtn");
    if (btn) btn.classList.add("recording");
    document.getElementById("micStatusText").textContent = "Listening... Speak now / सुन रहा हूँ...";
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    document.getElementById("voiceTranscriptFeedback").textContent = `Heard: "${transcript}"`;
    
    const lower = transcript.toLowerCase();
    const isYes = lower.includes("yes") || lower.includes("haan") || lower.includes("ha") || lower.includes("aam") || lower.includes("avunu") || lower.includes("hoy") || lower.includes("haa");
    const isNo = lower.includes("no") || lower.includes("nahi") || lower.includes("na") || lower.includes("illai") || lower.includes("ledu") || lower.includes("nahiye") || lower.includes("nathi");

    if (currentPointerStep === 4) {
      if (isYes) answerPointerYesNo("followup1", true);
      else if (isNo) answerPointerYesNo("followup1", false);
    } else if (currentPointerStep === 5) {
      if (isYes) answerPointerYesNo("followup2", true);
      else if (isNo) answerPointerYesNo("followup2", false);
    } else if (currentPointerStep === 6) {
      if (isYes) answerPointerYesNo("sugar", true);
      else if (isNo) answerPointerYesNo("sugar", false);
    } else if (currentPointerStep === 7) {
      if (isYes) answerPointerYesNo("bp", true);
      else if (isNo) answerPointerYesNo("bp", false);
    } else if (currentPointerStep === 8) {
      if (lower.includes("skip") || lower.includes("nahi") || lower.includes("no")) skipDocumentUpload();
    } else if (currentPointerStep === 9) {
      if (isYes) answerPointerYesNo("meds", true);
      else if (isNo) answerPointerYesNo("meds", false);
    } else if (currentPointerStep === 10) {
      if (isYes) answerPointerYesNo("allergy", true);
      else if (isNo) answerPointerYesNo("allergy", false);
    } else if (currentPointerStep === 11) {
      if (isYes) answerPointerYesNo("lifestyle", true);
      else if (isNo) answerPointerYesNo("lifestyle", false);
    }
  };

  recognition.onerror = () => {
    isRecording = false;
    const btn = document.getElementById("pointerMicBtn");
    if (btn) btn.classList.remove("recording");
    document.getElementById("micStatusText").textContent = "Tap to Speak / बोलकर बताएं";
  };

  recognition.onend = () => {
    isRecording = false;
    const btn = document.getElementById("pointerMicBtn");
    if (btn) btn.classList.remove("recording");
    document.getElementById("micStatusText").textContent = "Tap to Speak / बोलकर बताएं";
  };
}

function togglePointerVoice() {
  if (!recognition) {
    alert("Speech recognition is supported in Google Chrome & Microsoft Edge. Please use one of these browsers.");
    return;
  }
  if (isRecording) {
    recognition.stop();
  } else {
    const langMap = { en: "en-IN", hi: "hi-IN", ta: "ta-IN", te: "te-IN", bn: "bn-IN", mr: "mr-IN", gu: "gu-IN" };
    const activeLang = (activePatient && activePatient.language) ? activePatient.language : currentLanguage;
    recognition.lang = langMap[activeLang] || "en-IN";
    try {
      recognition.start();
    } catch (e) {
      console.warn(e);
    }
  }
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
